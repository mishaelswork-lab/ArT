# 🚀 INKFIND Platform - Getting Started Guide

> **Hey there!** This guide explains everything in simple terms - like I'm talking to a 15-year-old. No complicated tech jargon, I promise! 😊

---

## 📚 What Did We Just Build?

Think of your tattoo booking app like a **big restaurant chain** (like Domino's or McDonald's). Here's what we created:

### 🏗️ The "Kitchen" (Backend)
- This is where all the magic happens behind the scenes
- It stores all your data (artists, bookings, payments)
- It handles requests from the apps

### 🎨 The "Menu Boards" (Frontend Apps)
We built **3 different apps** for different people:

1. **Customer App** 📱 - For people who want tattoos
2. **Artist App** 🎨 - For tattoo artists to manage their work
3. **Admin App** ⚙️ - For you to manage everything

### 🗄️ The "Recipe Book" (Database)
- PostgreSQL database that stores ALL your information
- Think of it like a giant Excel sheet that never loses data

---

## 🎯 What YOU Can Do (Step by Step)

### Step 1: Get the Code on Your Computer

```bash
# 1. Open your terminal (Command Prompt on Windows, Terminal on Mac)
# 2. Go to where you want to save the project
cd Documents

# 3. Copy the project from GitHub (you'll need to upload it first)
git clone https://github.com/YOUR_USERNAME/inkfind-platform.git

# 4. Go into the project folder
cd inkfind-platform
```

**What this does:** Downloads all the code to your computer so you can work on it.

---

### Step 2: Install the Tools

#### For Mac Users:
```bash
# Install Homebrew (a tool installer)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Docker (like a container for your app)
brew install --cask docker

# Install Node.js (for running JavaScript)
brew install node

# Install Git (for code management)
brew install git
```

#### For Windows Users:
1. Download and install **Docker Desktop** from docker.com
2. Download and install **Node.js** from nodejs.org (get the LTS version)
3. Download and install **Git** from git-scm.com

**What this does:** Installs all the software you need to run the app.

---

### Step 3: Set Up Your Environment

```bash
# 1. Copy the example settings file
cp .env.example .env

# 2. Open .env in a text editor and fill in your details
# On Mac:
open -e .env

# On Windows:
notepad .env
```

**What to fill in:**
- `DB_PASSWORD` - Make up a strong password
- `JWT_SECRET` - Type random letters/numbers (at least 32 characters)
- `RAZORPAY_KEY_ID` - Get this from Razorpay dashboard (for payments)
- `RAZORPAY_KEY_SECRET` - Also from Razorpay
- `AWS_ACCESS_KEY_ID` - From AWS (for storing images)
- `AWS_SECRET_ACCESS_KEY` - Also from AWS
- `MSG91_AUTH_KEY` - From MSG91 (for SMS OTP)
- `ANTHROPIC_API_KEY` - From Anthropic (for AI consultant)

**What this does:** Tells the app where to find things like payment systems and image storage.

---

### Step 4: Start Everything Up!

```bash
# Start all the services (database, backend, frontend)
docker-compose up -d

# Wait about 30 seconds for everything to start up

# Check if it's working
curl http://localhost:3001/health
```

If you see `{"status":"ok"}`, everything is working! 🎉

**What this does:** Starts your entire app - database, backend server, and all 3 frontend apps.

---

### Step 5: Open the Apps in Your Browser

| App | URL | What It's For |
|-----|-----|---------------|
| Customer App | http://localhost:3000 | Customers find artists and book |
| Admin App | http://localhost:3002 | You manage everything |
| Artist App | http://localhost:3003 | Artists manage bookings |
| Database Admin | http://localhost:5050 | View/edit database |

**Login for testing:**
- **Admin:** Username: `admin`, Password: `admin123`
- **Artist:** Username: `arjun`, Password: `arjun123`

---

## 🛠️ What You Need to Set Up (External Services)

Think of these like setting up accounts on Instagram or Netflix - you need them for the app to work properly.

### 1. ☁️ AWS (Amazon Web Services) - For Storing Images
**Why:** To store artist portfolio photos
**Cost:** Free for first year (5GB storage)

**How to set up:**
1. Go to aws.amazon.com
2. Create an account
3. Search for "S3" and create a bucket called `inkfind-uploads`
4. Get your Access Key and Secret Key
5. Put them in your `.env` file

**Simple explanation:** AWS is like Google Drive but for apps. It stores all the tattoo photos.

---

### 2. 💳 Razorpay - For Payments
**Why:** So customers can pay the cover charge
**Cost:** 2% per transaction

**How to set up:**
1. Go to razorpay.com
2. Create a business account
3. Go to Settings → API Keys
4. Copy the Key ID and Key Secret
5. Put them in your `.env` file

**Simple explanation:** Razorpay is like PayPal or Google Pay. It handles all the money stuff safely.

---

### 3. 📱 MSG91 - For SMS (OTP)
**Why:** To send login codes to users' phones
**Cost:** ~₹0.15 per SMS

**How to set up:**
1. Go to msg91.com
2. Create an account
3. Get your Auth Key from the dashboard
4. Set up a sender ID (like "INKFIND")
5. Put them in your `.env` file

**Simple explanation:** MSG91 sends text messages to people's phones automatically.

---

### 4. 🤖 Anthropic (Claude) - For AI Consultant
**Why:** To give tattoo style recommendations
**Cost:** ~$0.01 per question

**How to set up:**
1. Go to console.anthropic.com
2. Create an account
3. Get an API key
4. Put it in your `.env` file

**Simple explanation:** This is the "brain" that suggests tattoo styles to customers.

---

## 📝 Daily Development Workflow

### When You Want to Make Changes:

```bash
# 1. Make sure everything is running
docker-compose ps

# 2. If not running, start it
docker-compose up -d

# 3. Make your code changes in your editor (VS Code, etc.)

# 4. See changes instantly - they update automatically!

# 5. When done, stop everything
docker-compose down
```

---

## 🧪 Testing Your Changes

### Test the API (Backend):
```bash
# Check if backend is working
curl http://localhost:3001/health

# Test login
curl -X POST http://localhost:3001/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"phone":"+919876543210","name":"Test User","role":"customer"}'
```

### Test the Frontend:
1. Open http://localhost:3000
2. Try to register with a phone number
3. Browse artists
4. Try to make a booking

---

## 🚀 Deploying to Production (Going Live!)

When you're ready to show the world:

### Option 1: Using GitHub Actions (Automatic)
1. Push your code to GitHub
2. Go to GitHub → Actions
3. Click "Deploy to Production"
4. Done! Your app is live!

### Option 2: Manual Deployment
```bash
# Build the Docker images
docker-compose -f docker-compose.prod.yml build

# Push to your server
# (You'll need a server from AWS, DigitalOcean, etc.)
```

---

## 🐛 Common Problems & Fixes

### Problem: "Port already in use"
**Fix:** Something else is using that port. Change it in `.env`:
```
BACKEND_PORT=3002  # Instead of 3001
```

### Problem: "Database connection failed"
**Fix:** The database isn't running. Start it:
```bash
docker-compose up postgres -d
```

### Problem: "Changes not showing up"
**Fix:** Restart the service:
```bash
docker-compose restart backend
```

### Problem: "Out of memory"
**Fix:** Docker is using too much RAM. Increase Docker's memory limit in Docker Desktop settings.

---

## 📖 File Structure Explained

```
inkfind-platform/
├── 📁 backend/           ← The "kitchen" (server code)
│   ├── src/
│   │   ├── controllers/  ← Handle requests
│   │   ├── models/       ← Database stuff
│   │   ├── routes/       ← API endpoints
│   │   └── services/     ← Business logic
│   └── migrations/       ← Database setup files
│
├── 📁 frontend/          ← The "menu boards" (apps)
│   ├── apps/
│   │   ├── customer/     ← Customer app
│   │   ├── admin/        ← Admin app
│   │   └── artist/       ← Artist app
│   └── packages/         ← Shared code
│
├── 📁 docs/              ← Documentation
├── 📁 infrastructure/    ← Docker & deployment files
├── docker-compose.yml    ← Starts everything
└── .env.example          ← Settings template
```

---

## 💡 Tips for Success

1. **Start Small** - Don't try to understand everything at once
2. **Use VS Code** - It's free and helps with coding
3. **Ask for Help** - Use ChatGPT, Stack Overflow, or GitHub Issues
4. **Take Breaks** - Coding is hard, rest is important!
5. **Write Things Down** - Keep notes of what you learn

---

## 🎓 Learning Resources

### Free Resources:
- **JavaScript:** javascript.info
- **React:** react.dev
- **Node.js:** nodejs.dev
- **SQL:** sqlbolt.com

### YouTube Channels:
- Traversy Media
- Fireship
- Web Dev Simplified

---

## 📞 Need Help?

If you get stuck:
1. Check the error message carefully
2. Google the error (someone else had the same problem!)
3. Ask on Stack Overflow
4. Check GitHub Issues

---

## ✅ Your Checklist

- [ ] Install Docker, Node.js, Git
- [ ] Clone the repository
- [ ] Set up `.env` file
- [ ] Start with `docker-compose up -d`
- [ ] Open http://localhost:3000
- [ ] Create AWS account and S3 bucket
- [ ] Create Razorpay account
- [ ] Create MSG91 account
- [ ] Create Anthropic account
- [ ] Update `.env` with all API keys
- [ ] Test the full booking flow
- [ ] Deploy to production!

---

## 🎉 You're Ready!

You now have everything you need to run and grow your INKFIND platform. Remember:

- **Don't panic** when things break - it's normal!
- **Google is your friend** - every problem has been solved before
- **Take it one step at a time** - you don't need to learn everything today

Good luck! You've got this! 💪

---

*Built with ❤️ for the INKFIND Platform*
