# 🎨 INKFIND Platform

> A scalable, production-ready tattoo booking platform for India

[![CI](https://github.com/yourusername/inkfind-platform/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/inkfind-platform/actions/workflows/ci.yml)
[![CD](https://github.com/yourusername/inkfind-platform/actions/workflows/deploy.yml/badge.svg)](https://github.com/yourusername/inkfind-platform/actions/workflows/deploy.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Features](#features)
- [Quick Start](#quick-start)
- [Documentation](#documentation)
- [Deployment](#deployment)
- [Contributing](#contributing)

---

## 🎯 Overview

INKFIND is a pan-India tattoo booking platform that connects customers with verified tattoo artists and studios. The platform features:

- **3 User Interfaces:** Customer, Artist, and Admin dashboards
- **Real-time Booking System** with cover charge payments
- **AI-powered Style Consultant** for tattoo recommendations
- **Geolocation-based Search** for nearby studios
- **Secure Payment Integration** with Razorpay
- **SMS OTP Authentication** via MSG91
- **Portfolio Management** for artists

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         INKFIND PLATFORM                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │   Customer  │  │    Admin    │  │   Artist    │  Frontend   │
│  │     App     │  │    Panel    │  │  Dashboard  │  (Next.js)  │
│  │   :3000     │  │    :3002    │  │    :3003    │             │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘             │
│         │                │                │                     │
│         └────────────────┼────────────────┘                     │
│                          │                                      │
│                    ┌─────┴─────┐                               │
│                    │   Nginx   │  Reverse Proxy                │
│                    │   :80     │                               │
│                    └─────┬─────┘                               │
│                          │                                      │
│  ┌───────────────────────┼───────────────────────┐             │
│  │                       │                       │             │
│  │              ┌────────┴────────┐              │             │
│  │              │  Backend API    │              │  Backend    │
│  │              │    Node.js      │              │  (Express)  │
│  │              │    :3001        │              │             │
│  │              └────────┬────────┘              │             │
│  │                       │                       │             │
│  │         ┌─────────────┼─────────────┐         │             │
│  │         │             │             │         │             │
│  │    ┌────┴────┐  ┌────┴────┐  ┌────┴────┐    │             │
│  │    │PostgreSQL│  │  Redis  │  │  AWS S3 │    │  Services   │
│  │    │  :5432  │  │  :6379  │  │  Images │    │             │
│  │    └─────────┘  └─────────┘  └─────────┘    │             │
│  │                                               │             │
│  └───────────────────────────────────────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Tech Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | Next.js 14, React 18, TypeScript, Tailwind CSS |
| **Backend** | Node.js, Express, TypeScript |
| **Database** | PostgreSQL 15 + PostGIS |
| **Cache** | Redis 7 |
| **Storage** | AWS S3 + CloudFront CDN |
| **Payments** | Razorpay |
| **SMS** | MSG91 |
| **AI** | Anthropic Claude |
| **Auth** | JWT + Phone OTP |
| **Real-time** | Socket.io |
| **Monitoring** | Sentry |

---

## ✨ Features

### Customer App
- 📍 Location-based studio/artist search
- 🔍 Filter by style, rating, availability
- 🖼️ Browse artist portfolios
- 🤖 AI style consultant
- 📅 Book appointments with time slots
- 💳 Pay cover charge via Razorpay
- 🔔 Real-time booking notifications
- ⭐ Rate and review artists

### Artist Dashboard
- 📊 Booking management (accept/reject)
- 🖼️ Portfolio upload and management
- ⏰ Availability toggle
- 💰 Earnings tracking
- 📱 Push notifications

### Admin Panel
- 👥 Artist management (add/edit/remove)
- 🏢 Sub-admin creation
- 📈 Analytics dashboard
- 🏙️ City management
- 💳 Payment oversight
- 📊 Booking monitoring

---

## 🚀 Quick Start

### Prerequisites

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)
- [Node.js 20+](https://nodejs.org/)
- [Git](https://git-scm.com/)

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/inkfind-platform.git
cd inkfind-platform

# 2. Copy environment file
cp .env.example .env

# 3. Edit .env with your API keys
# (See GETTING-STARTED.md for details)

# 4. Start all services
docker-compose up -d

# 5. Wait for services to start (30 seconds)
sleep 30

# 6. Verify everything is working
curl http://localhost:3001/health
```

### Access the Apps

| Service | URL | Description |
|---------|-----|-------------|
| Customer App | http://localhost:3000 | Main customer interface |
| Admin Panel | http://localhost:3002 | Admin dashboard |
| Artist Dashboard | http://localhost:3003 | Artist interface |
| API Documentation | http://localhost:3001/docs | Swagger API docs |
| Database Admin | http://localhost:5050 | pgAdmin interface |
| Redis Admin | http://localhost:8081 | Redis Commander |

### Default Credentials

- **Admin:** `admin` / `admin123`
- **Artist:** `arjun` / `arjun123`

---

## 📚 Documentation

- [API Specification](./docs/API-SPECIFICATION.md) - Complete API reference
- [Getting Started](./GETTING-STARTED.md) - Step-by-step setup guide
- [Database Schema](./backend/migrations/) - SQL migrations
- [Architecture Decisions](./docs/ARCHITECTURE.md) - Design decisions (coming soon)

---

## 🚢 Deployment

### Using GitHub Actions (Recommended)

1. Push code to GitHub
2. Go to Actions → Deploy
3. Select environment (staging/production)
4. Click "Run workflow"

### Manual Deployment

```bash
# Build production images
docker-compose -f docker-compose.yml -f docker-compose.prod.yml build

# Deploy to your server
# (Requires AWS ECS, Kubernetes, or similar)
```

### Required Environment Variables

See `.env.example` for all required variables. Key ones:

```bash
# Database
DB_PASSWORD=your_secure_password

# JWT
JWT_SECRET=your_32_character_secret

# Payments (Razorpay)
RAZORPAY_KEY_ID=rzp_test_xxx
RAZORPAY_KEY_SECRET=xxx

# Storage (AWS)
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
AWS_S3_BUCKET=inkfind-uploads

# SMS (MSG91)
MSG91_AUTH_KEY=xxx

# AI (Anthropic)
ANTHROPIC_API_KEY=sk-ant-xxx
```

---

## 🧪 Testing

```bash
# Run backend tests
cd backend && npm test

# Run frontend tests
cd frontend/apps/customer && npm test

# Run all tests
docker-compose -f docker-compose.test.yml up
```

---

## 📁 Project Structure

```
inkfind-platform/
├── 📁 backend/              # Node.js API server
│   ├── src/
│   │   ├── controllers/     # Request handlers
│   │   ├── middleware/      # Auth, validation
│   │   ├── models/          # Database models
│   │   ├── routes/          # API routes
│   │   ├── services/        # Business logic
│   │   └── utils/           # Helpers
│   ├── migrations/          # Database migrations
│   └── tests/               # Test files
│
├── 📁 frontend/             # Next.js applications
│   ├── apps/
│   │   ├── customer/        # Customer app
│   │   ├── admin/           # Admin panel
│   │   └── artist/          # Artist dashboard
│   └── packages/            # Shared packages
│       ├── types/           # TypeScript types
│       ├── ui/              # Shared components
│       └── utils/           # Shared utilities
│
├── 📁 docs/                 # Documentation
├── 📁 infrastructure/       # Docker, CI/CD
│   ├── docker/              # Dockerfiles
│   ├── github-actions/      # CI/CD workflows
│   └── nginx/               # Nginx config
│
├── docker-compose.yml       # Development setup
├── docker-compose.prod.yml  # Production setup
└── .env.example             # Environment template
```

---

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](./CONTRIBUTING.md) for details.

### Development Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.

---

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) - React framework
- [Tailwind CSS](https://tailwindcss.com/) - CSS framework
- [PostgreSQL](https://www.postgresql.org/) - Database
- [Razorpay](https://razorpay.com/) - Payment gateway
- [MSG91](https://msg91.com/) - SMS service

---

## 📞 Support

- 📧 Email: support@inkfind.in
- 💬 Discord: [Join our community](https://discord.gg/inkfind)
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/inkfind-platform/issues)

---

<p align="center">
  Built with ❤️ for the tattoo community
</p>
