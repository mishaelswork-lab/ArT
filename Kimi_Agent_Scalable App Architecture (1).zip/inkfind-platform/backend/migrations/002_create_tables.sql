-- Migration: 002_create_tables
-- Description: Create core database tables
-- Created: 2026-03-29

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('usr'),
    phone VARCHAR(15) UNIQUE NOT NULL,
    email VARCHAR(255),
    password_hash VARCHAR(255),
    role VARCHAR(20) NOT NULL CHECK (role IN ('super_admin', 'sub_admin', 'artist', 'customer')),
    name VARCHAR(100) NOT NULL,
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    last_login_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for users
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_active ON users(is_active);

-- Trigger for updated_at
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- CITIES TABLE
-- ============================================
CREATE TABLE cities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('city'),
    name VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    country VARCHAR(100) DEFAULT 'India',
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for cities
CREATE INDEX idx_cities_name ON cities(name);
CREATE INDEX idx_cities_state ON cities(state);
CREATE INDEX idx_cities_location ON cities USING GIST (
    ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography
);

-- Trigger for updated_at
CREATE TRIGGER update_cities_updated_at
    BEFORE UPDATE ON cities
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- STUDIOS TABLE
-- ============================================
CREATE TABLE studios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('stu'),
    name VARCHAR(200) NOT NULL,
    owner_id UUID REFERENCES users(id),
    city_id UUID REFERENCES cities(id),
    address TEXT NOT NULL,
    area VARCHAR(100),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    phone VARCHAR(15),
    email VARCHAR(255),
    website VARCHAR(255),
    description TEXT,
    cover_image_url TEXT,
    images TEXT[],
    styles TEXT[],
    opening_hours JSONB,
    rating DECIMAL(2, 1) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
    review_count INTEGER DEFAULT 0,
    is_verified BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for studios
CREATE INDEX idx_studios_city ON studios(city_id);
CREATE INDEX idx_studios_owner ON studios(owner_id);
CREATE INDEX idx_studios_active ON studios(is_active);
CREATE INDEX idx_studios_verified ON studios(is_verified);
CREATE INDEX idx_studios_location ON studios USING GIST (
    ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography
);
CREATE INDEX idx_studios_styles ON studios USING GIN(styles);
CREATE INDEX idx_studios_rating ON studios(rating DESC);

-- Trigger for updated_at
CREATE TRIGGER update_studios_updated_at
    BEFORE UPDATE ON studios
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- ARTISTS TABLE
-- ============================================
CREATE TABLE artists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('art'),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    studio_id UUID REFERENCES studios(id),
    specialty VARCHAR(200) NOT NULL,
    bio TEXT,
    hourly_rate INTEGER NOT NULL CHECK (hourly_rate > 0),
    experience_years INTEGER DEFAULT 0,
    styles TEXT[],
    avatar_url TEXT,
    is_available BOOLEAN DEFAULT true,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for artists
CREATE INDEX idx_artists_user ON artists(user_id);
CREATE INDEX idx_artists_studio ON artists(studio_id);
CREATE INDEX idx_artists_available ON artists(is_available);
CREATE INDEX idx_artists_active ON artists(is_active);
CREATE INDEX idx_artists_styles ON artists USING GIN(styles);
CREATE INDEX idx_artists_rate ON artists(hourly_rate);

-- Trigger for updated_at
CREATE TRIGGER update_artists_updated_at
    BEFORE UPDATE ON artists
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- PORTFOLIO_IMAGES TABLE
-- ============================================
CREATE TABLE portfolio_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('img'),
    artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    thumbnail_url TEXT,
    caption TEXT,
    style_tags TEXT[],
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for portfolio_images
CREATE INDEX idx_portfolio_artist ON portfolio_images(artist_id);
CREATE INDEX idx_portfolio_active ON portfolio_images(is_active);
CREATE INDEX idx_portfolio_order ON portfolio_images(display_order);

-- Trigger for updated_at
CREATE TRIGGER update_portfolio_images_updated_at
    BEFORE UPDATE ON portfolio_images
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- ARTIST_SLOTS TABLE
-- ============================================
CREATE TABLE artist_slots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
    slot_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    duration_minutes INTEGER NOT NULL,
    is_booked BOOLEAN DEFAULT false,
    is_available BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(artist_id, slot_date, start_time)
);

-- Indexes for artist_slots
CREATE INDEX idx_slots_artist ON artist_slots(artist_id);
CREATE INDEX idx_slots_date ON artist_slots(slot_date);
CREATE INDEX idx_slots_available ON artist_slots(is_available, is_booked);
CREATE INDEX idx_slots_date_time ON artist_slots(slot_date, start_time);

-- Trigger for updated_at
CREATE TRIGGER update_artist_slots_updated_at
    BEFORE UPDATE ON artist_slots
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- BOOKINGS TABLE
-- ============================================
CREATE TYPE booking_status AS ENUM (
    'pending_payment',
    'pending_artist',
    'confirmed',
    'rejected',
    'completed',
    'cancelled',
    'refunded'
);

CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('bkp'),
    customer_id UUID REFERENCES users(id),
    artist_id UUID REFERENCES artists(id),
    studio_id UUID REFERENCES studios(id),
    slot_id UUID REFERENCES artist_slots(id),
    status booking_status DEFAULT 'pending_payment',
    cover_charge_amount INTEGER NOT NULL,
    cover_charge_paid BOOLEAN DEFAULT false,
    payment_id VARCHAR(100),
    tattoo_description TEXT NOT NULL,
    placement VARCHAR(100),
    estimated_size VARCHAR(50),
    reference_images TEXT[],
    rejection_reason TEXT,
    cancellation_reason TEXT,
    cancelled_by UUID REFERENCES users(id),
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for bookings
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_artist ON bookings(artist_id);
CREATE INDEX idx_bookings_studio ON bookings(studio_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_created ON bookings(created_at DESC);
CREATE INDEX idx_bookings_slot ON bookings(slot_id);

-- Trigger for updated_at
CREATE TRIGGER update_bookings_updated_at
    BEFORE UPDATE ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- BOOKING_TIMELINE TABLE
-- ============================================
CREATE TABLE booking_timeline (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    status booking_status NOT NULL,
    message TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for booking_timeline
CREATE INDEX idx_timeline_booking ON booking_timeline(booking_id);
CREATE INDEX idx_timeline_created ON booking_timeline(created_at);

-- ============================================
-- REVIEWS TABLE
-- ============================================
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('rev'),
    booking_id UUID REFERENCES bookings(id),
    customer_id UUID REFERENCES users(id),
    artist_id UUID REFERENCES artists(id),
    studio_id UUID REFERENCES studios(id),
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(booking_id)
);

-- Indexes for reviews
CREATE INDEX idx_reviews_artist ON reviews(artist_id);
CREATE INDEX idx_reviews_studio ON reviews(studio_id);
CREATE INDEX idx_reviews_customer ON reviews(customer_id);
CREATE INDEX idx_reviews_rating ON reviews(rating);
CREATE INDEX idx_reviews_created ON reviews(created_at DESC);

-- Trigger for updated_at
CREATE TRIGGER update_reviews_updated_at
    BEFORE UPDATE ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- PAYMENTS TABLE
-- ============================================
CREATE TYPE payment_status AS ENUM (
    'created',
    'authorized',
    'captured',
    'failed',
    'refunded',
    'partially_refunded'
);

CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('pay'),
    booking_id UUID REFERENCES bookings(id),
    user_id UUID REFERENCES users(id),
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(255),
    amount INTEGER NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    status payment_status DEFAULT 'created',
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for payments
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_razorpay ON payments(razorpay_order_id);
CREATE INDEX idx_payments_status ON payments(status);

-- Trigger for updated_at
CREATE TRIGGER update_payments_updated_at
    BEFORE UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TYPE notification_type AS ENUM (
    'booking_created',
    'booking_confirmed',
    'booking_rejected',
    'booking_cancelled',
    'payment_received',
    'payment_failed',
    'review_received',
    'general'
);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    short_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('not'),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    type notification_type DEFAULT 'general',
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    data JSONB,
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for notifications
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_notifications_created ON notifications(created_at DESC);
CREATE INDEX idx_notifications_type ON notifications(type);

-- ============================================
-- SUB_ADMINS TABLE
-- ============================================
CREATE TABLE sub_admins (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    created_by UUID REFERENCES users(id),
    can_add_artists BOOLEAN DEFAULT true,
    can_manage_bookings BOOLEAN DEFAULT true,
    can_manage_payments BOOLEAN DEFAULT false,
    can_manage_cities BOOLEAN DEFAULT false,
    assigned_cities UUID[],
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for sub_admins
CREATE INDEX idx_sub_admins_user ON sub_admins(user_id);
CREATE INDEX idx_sub_admins_active ON sub_admins(is_active);

-- Trigger for updated_at
CREATE TRIGGER update_sub_admins_updated_at
    BEFORE UPDATE ON sub_admins
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- OTP TABLE (for phone verification)
-- ============================================
CREATE TABLE otps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone VARCHAR(15) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    otp_id VARCHAR(20) UNIQUE DEFAULT generate_short_id('otp'),
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    expires_at TIMESTAMP NOT NULL,
    is_verified BOOLEAN DEFAULT false,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for otps
CREATE INDEX idx_otps_phone ON otps(phone);
CREATE INDEX idx_otps_otp_id ON otps(otp_id);
CREATE INDEX idx_otps_expires ON otps(expires_at);

-- ============================================
-- REFRESH_TOKENS TABLE
-- ============================================
CREATE TABLE refresh_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    is_revoked BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    revoked_at TIMESTAMP
);

-- Indexes for refresh_tokens
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token ON refresh_tokens(token);
CREATE INDEX idx_refresh_tokens_expires ON refresh_tokens(expires_at);

-- ============================================
-- AI_CONSULTATIONS TABLE (for tracking AI usage)
-- ============================================
CREATE TABLE ai_consultations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    query TEXT NOT NULL,
    response TEXT NOT NULL,
    suggested_artists UUID[],
    suggested_styles TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for ai_consultations
CREATE INDEX idx_ai_user ON ai_consultations(user_id);
CREATE INDEX idx_ai_created ON ai_consultations(created_at);
