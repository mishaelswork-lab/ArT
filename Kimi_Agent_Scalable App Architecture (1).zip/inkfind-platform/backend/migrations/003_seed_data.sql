-- Migration: 003_seed_data
-- Description: Seed initial data for development
-- Created: 2026-03-29

-- ============================================
-- SEED CITIES
-- ============================================
INSERT INTO cities (name, state, latitude, longitude) VALUES
('Bengaluru', 'Karnataka', 12.9716, 77.5946),
('Mumbai', 'Maharashtra', 19.0760, 72.8777),
('Delhi', 'Delhi', 28.6139, 77.2090),
('Hyderabad', 'Telangana', 17.3850, 78.4867),
('Chennai', 'Tamil Nadu', 13.0827, 80.2707),
('Kolkata', 'West Bengal', 22.5726, 88.3639),
('Pune', 'Maharashtra', 18.5204, 73.8567),
('Ahmedabad', 'Gujarat', 23.0225, 72.5714),
('Jaipur', 'Rajasthan', 26.9124, 75.7873),
('Lucknow', 'Uttar Pradesh', 26.8467, 80.9462);

-- ============================================
-- SEED SUPER ADMIN
-- ============================================
INSERT INTO users (phone, email, role, name, is_verified, is_active) VALUES
('+919999999999', 'admin@inkfind.in', 'super_admin', 'Super Admin', true, true);

-- ============================================
-- SEED STUDIOS (Bengaluru)
-- ============================================
WITH bengaluru AS (SELECT id FROM cities WHERE name = 'Bengaluru')
INSERT INTO studios (name, city_id, address, area, latitude, longitude, phone, email, description, styles, rating, review_count, is_verified, is_active)
SELECT 
    'Black Lotus Studio',
    bengaluru.id,
    '123, 12th Main Road, Indiranagar',
    'Indiranagar',
    12.9784,
    77.6408,
    '+919876543210',
    'contact@blacklotus.in',
    'Premium tattoo studio specializing in blackwork, fine line, and geometric designs. Our artists bring years of experience and artistic vision to every piece.',
    ARRAY['Blackwork', 'Fine Line', 'Geometric'],
    4.9,
    214,
    true,
    true
FROM bengaluru;

WITH bengaluru AS (SELECT id FROM cities WHERE name = 'Bengaluru')
INSERT INTO studios (name, city_id, address, area, latitude, longitude, phone, email, description, styles, rating, review_count, is_verified, is_active)
SELECT 
    'Ink & Iron',
    bengaluru.id,
    '456, 80 Feet Road, Koramangala',
    'Koramangala',
    12.9352,
    77.6245,
    '+919876543211',
    'hello@inkandiron.in',
    'Traditional Japanese tattooing meets modern artistry. Our master artist trained in Kyoto brings authentic Japanese storytelling to Bangalore.',
    ARRAY['Japanese', 'Neo-Traditional', 'Realism'],
    4.7,
    189,
    true,
    true
FROM bengaluru;

WITH bengaluru AS (SELECT id FROM cities WHERE name = 'Bengaluru')
INSERT INTO studios (name, city_id, address, area, latitude, longitude, phone, email, description, styles, rating, review_count, is_verified, is_active)
SELECT 
    'Chromatic Skin',
    bengaluru.id,
    '789, 4th Block, Jayanagar',
    'Jayanagar',
    12.9250,
    77.5938,
    '+919876543212',
    'art@chromaticskin.in',
    'Where watercolor meets skin. Our artists create dreamlike compositions that blur the line between body art and fine art.',
    ARRAY['Watercolour', 'Illustrative', 'Surrealism'],
    4.8,
    302,
    true,
    true
FROM bengaluru;

WITH bengaluru AS (SELECT id FROM cities WHERE name = 'Bengaluru')
INSERT INTO studios (name, city_id, address, area, latitude, longitude, phone, email, description, styles, rating, review_count, is_verified, is_active)
SELECT 
    'Needle & Thread',
    bengaluru.id,
    '321, Sector 7, HSR Layout',
    'HSR Layout',
    12.9116,
    77.6389,
    '+919876543213',
    'minimal@needlethread.in',
    'Clean lines, intentional space. Every tattoo says exactly what it needs to — nothing more. Specializing in minimalist and script work.',
    ARRAY['Minimalist', 'Script', 'Dotwork'],
    4.6,
    97,
    true,
    true
FROM bengaluru;

WITH bengaluru AS (SELECT id FROM cities WHERE name = 'Bengaluru')
INSERT INTO studios (name, city_id, address, area, latitude, longitude, phone, email, description, styles, rating, review_count, is_verified, is_active)
SELECT 
    'Sacred Skin',
    bengaluru.id,
    '654, ITPL Road, Whitefield',
    'Whitefield',
    12.9698,
    77.7499,
    '+919876543214',
    'spiritual@sacredskin.in',
    'Deeply rooted in South Asian spiritual art. Each mandala is a meditation made permanent. Ornamental and spiritual tattoo specialists.',
    ARRAY['Mandala', 'Spiritual', 'Ornamental'],
    4.8,
    156,
    true,
    true
FROM bengaluru;

-- ============================================
-- SEED ARTIST USERS
-- ============================================
INSERT INTO users (phone, email, role, name, is_verified, is_active) VALUES
('+919876543220', 'arjun@blacklotus.in', 'artist', 'Arjun Mehta', true, true),
('+919876543221', 'priya@blacklotus.in', 'artist', 'Priya Nair', true, true),
('+919876543222', 'rohan@inkandiron.in', 'artist', 'Rohan Das', true, true),
('+919876543223', 'sneha@chromaticskin.in', 'artist', 'Sneha Rao', true, true),
('+919876543224', 'kavitha@needlethread.in', 'artist', 'Kavitha Shetty', true, true),
('+919876543225', 'dev@sacredskin.in', 'artist', 'Dev Krishnan', true, true);

-- ============================================
-- SEED ARTISTS
-- ============================================
INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Blackwork & Geometric',
    '10 years crafting bold blackwork. Influenced by sacred geometry and South Indian temple art. Every piece tells a story of precision and power.',
    3500,
    10,
    ARRAY['Blackwork', 'Geometric', 'Mandala'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Arjun Mehta' AND s.name = 'Black Lotus Studio';

INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Fine Line & Botanical',
    'Delicate fine-line work inspired by Indian flora. Trained in Seoul and Mumbai. Bringing nature''s beauty to skin with surgical precision.',
    4000,
    7,
    ARRAY['Fine Line', 'Botanical', 'Minimalist'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Priya Nair' AND s.name = 'Black Lotus Studio';

INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Japanese Traditional',
    'Apprenticed under a master in Kyoto for 5 years. Brings authentic Japanese storytelling and technique to every piece. Irezumi is my life.',
    5000,
    12,
    ARRAY['Japanese', 'Neo-Traditional', 'Realism'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Rohan Das' AND s.name = 'Ink & Iron';

INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Watercolour & Surrealism',
    'Fine arts background from MSU Baroda. Creates dreamlike compositions that blur skin and canvas. Watercolor tattoos that look like paintings.',
    4500,
    6,
    ARRAY['Watercolour', 'Illustrative', 'Surrealism'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Sneha Rao' AND s.name = 'Chromatic Skin';

INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Minimalist & Script',
    'Clean lines, intentional space. Every tattoo says exactly what it needs to — nothing more. Typography and minimal design specialist.',
    2800,
    4,
    ARRAY['Minimalist', 'Script', 'Dotwork'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Kavitha Shetty' AND s.name = 'Needle & Thread';

INSERT INTO artists (user_id, studio_id, specialty, bio, hourly_rate, experience_years, styles, is_available, is_active)
SELECT 
    u.id,
    s.id,
    'Mandala & Ornamental',
    'Deeply rooted in South Asian spiritual art. Each mandala is a meditation made permanent. Trained in traditional henna before moving to tattoos.',
    4200,
    8,
    ARRAY['Mandala', 'Spiritual', 'Ornamental'],
    true,
    true
FROM users u, studios s
WHERE u.name = 'Dev Krishnan' AND s.name = 'Sacred Skin';

-- ============================================
-- SEED ARTIST SLOTS (for next 7 days)
-- ============================================
INSERT INTO artist_slots (artist_id, slot_date, start_time, end_time, duration_minutes, is_available, is_booked)
SELECT 
    a.id,
    CURRENT_DATE + INTERVAL '1 day',
    '10:00',
    '12:00',
    120,
    true,
    false
FROM artists a
WHERE a.name IN (SELECT name FROM users WHERE role = 'artist');

INSERT INTO artist_slots (artist_id, slot_date, start_time, end_time, duration_minutes, is_available, is_booked)
SELECT 
    a.id,
    CURRENT_DATE + INTERVAL '1 day',
    '14:00',
    '16:00',
    120,
    true,
    false
FROM artists a;

INSERT INTO artist_slots (artist_id, slot_date, start_time, end_time, duration_minutes, is_available, is_booked)
SELECT 
    a.id,
    CURRENT_DATE + INTERVAL '2 days',
    '11:00',
    '13:00',
    120,
    true,
    false
FROM artists a;

INSERT INTO artist_slots (artist_id, slot_date, start_time, end_time, duration_minutes, is_available, is_booked)
SELECT 
    a.id,
    CURRENT_DATE + INTERVAL '3 days',
    '15:00',
    '17:00',
    120,
    true,
    false
FROM artists a;

-- ============================================
-- SEED SAMPLE BOOKINGS
-- ============================================
-- First create a sample customer
INSERT INTO users (phone, email, role, name, is_verified, is_active) VALUES
('+919876543230', 'customer@example.com', 'customer', 'Rahul Sharma', true, true);

-- Create sample bookings
INSERT INTO bookings (customer_id, artist_id, studio_id, cover_charge_amount, cover_charge_paid, status, tattoo_description, placement, estimated_size)
SELECT 
    c.id,
    a.id,
    s.id,
    50000,
    true,
    'confirmed',
    'Small lotus on wrist, fine line style with minimal shading',
    'Left wrist',
    '5cm x 5cm'
FROM users c, artists a, studios s
WHERE c.name = 'Rahul Sharma' AND a.specialty = 'Fine Line & Botanical' AND s.name = 'Black Lotus Studio';

INSERT INTO bookings (customer_id, artist_id, studio_id, cover_charge_amount, cover_charge_paid, status, tattoo_description, placement, estimated_size)
SELECT 
    c.id,
    a.id,
    s.id,
    50000,
    true,
    'pending_artist',
    'Geometric wolf design for shoulder blade',
    'Right shoulder blade',
    '10cm x 8cm'
FROM users c, artists a, studios s
WHERE c.name = 'Rahul Sharma' AND a.specialty = 'Blackwork & Geometric' AND s.name = 'Black Lotus Studio';

-- ============================================
-- SEED SAMPLE REVIEWS
-- ============================================
INSERT INTO reviews (booking_id, customer_id, artist_id, studio_id, rating, comment, is_verified)
SELECT 
    b.id,
    b.customer_id,
    b.artist_id,
    b.studio_id,
    5,
    'Amazing experience! Priya was so patient and understood exactly what I wanted. The fine line work is incredible. Highly recommend!',
    true
FROM bookings b
WHERE b.status = 'confirmed';

-- Update artist and studio ratings
UPDATE artists SET rating = 5.0, review_count = 1 WHERE specialty = 'Fine Line & Botanical';
UPDATE studios SET rating = 5.0, review_count = 1 WHERE name = 'Black Lotus Studio';
