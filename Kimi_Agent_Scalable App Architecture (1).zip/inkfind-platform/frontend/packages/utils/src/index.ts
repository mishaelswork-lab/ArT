// ============================================
// INKFIND Platform - Shared Utilities
// ============================================

import { format, formatDistanceToNow, parseISO } from 'date-fns';

// ============================================
// Formatting Utilities
// ============================================

/**
 * Format price in Indian Rupees
 */
export function formatPrice(amount: number, currency: string = 'INR'): string {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
  return formatter.format(amount / 100); // Convert paise to rupees
}

/**
 * Format price without currency symbol
 */
export function formatPriceNumber(amount: number): string {
  const formatter = new Intl.NumberFormat('en-IN');
  return formatter.format(amount / 100);
}

/**
 * Format date to readable string
 */
export function formatDate(date: string | Date, formatStr: string = 'MMM d, yyyy'): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, formatStr);
}

/**
 * Format time
 */
export function formatTime(date: string | Date, formatStr: string = 'h:mm a'): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, formatStr);
}

/**
 * Format relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return formatDistanceToNow(d, { addSuffix: true });
}

/**
 * Format phone number to Indian format
 */
export function formatPhone(phone: string): string {
  if (phone.startsWith('+91')) {
    return phone.replace(/(\+91)(\d{5})(\d{5})/, '$1 $2 $3');
  }
  return phone;
}

// ============================================
// Distance Utilities
// ============================================

/**
 * Format distance in km or meters
 */
export function formatDistance(distanceKm: number): string {
  if (distanceKm < 1) {
    return `${Math.round(distanceKm * 1000)} m`;
  }
  return `${distanceKm.toFixed(1)} km`;
}

/**
 * Calculate distance between two coordinates using Haversine formula
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

// ============================================
// Validation Utilities
// ============================================

/**
 * Validate Indian phone number
 */
export function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+91[6-9]\d{9}$/;
  return phoneRegex.test(phone);
}

/**
 * Validate email address
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate OTP (6 digits)
 */
export function isValidOTP(otp: string): boolean {
  const otpRegex = /^\d{6}$/;
  return otpRegex.test(otp);
}

// ============================================
// String Utilities
// ============================================

/**
 * Truncate text with ellipsis
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength - 3) + '...';
}

/**
 * Capitalize first letter
 */
export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Convert to title case
 */
export function toTitleCase(str: string): string {
  return str
    .split(' ')
    .map((word) => capitalize(word.toLowerCase()))
    .join(' ');
}

/**
 * Generate initials from name
 */
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

// ============================================
// Array Utilities
// ============================================

/**
 * Group array by key
 */
export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce((groups, item) => {
    const groupKey = String(item[key]);
    return {
      ...groups,
      [groupKey]: [...(groups[groupKey] || []), item],
    };
  }, {} as Record<string, T[]>);
}

/**
 * Remove duplicates from array
 */
export function unique<T>(array: T[]): T[] {
  return [...new Set(array)];
}

/**
 * Sort array by key
 */
export function sortBy<T>(array: T[], key: keyof T, order: 'asc' | 'desc' = 'asc'): T[] {
  return [...array].sort((a, b) => {
    const aVal = a[key];
    const bVal = b[key];
    if (aVal < bVal) return order === 'asc' ? -1 : 1;
    if (aVal > bVal) return order === 'asc' ? 1 : -1;
    return 0;
  });
}

// ============================================
// Storage Utilities
// ============================================

const STORAGE_PREFIX = 'inkfind_';

/**
 * Get item from localStorage
 */
export function getStorageItem<T>(key: string, defaultValue?: T): T | undefined {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const item = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

/**
 * Set item in localStorage
 */
export function setStorageItem<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(value));
  } catch {
    // Ignore storage errors
  }
}

/**
 * Remove item from localStorage
 */
export function removeStorageItem(key: string): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(`${STORAGE_PREFIX}${key}`);
}

/**
 * Clear all inkfind items from localStorage
 */
export function clearStorage(): void {
  if (typeof window === 'undefined') return;
  Object.keys(localStorage)
    .filter((key) => key.startsWith(STORAGE_PREFIX))
    .forEach((key) => localStorage.removeItem(key));
}

// ============================================
// Debounce/Throttle Utilities
// ============================================

/**
 * Debounce function
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Throttle function
 */
export function throttle<T extends (...args: unknown[]) => unknown>(
  fn: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle = false;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      fn(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

// ============================================
// Booking Status Utilities
// ============================================

import { BookingStatus } from '@inkfind/types';

export const bookingStatusConfig: Record<
  BookingStatus,
  { label: string; color: string; bgColor: string }
> = {
  pending_payment: {
    label: 'Pending Payment',
    color: '#f0b429',
    bgColor: 'rgba(240, 180, 41, 0.12)',
  },
  pending_artist: {
    label: 'Awaiting Confirmation',
    color: '#f0b429',
    bgColor: 'rgba(240, 180, 41, 0.12)',
  },
  confirmed: {
    label: 'Confirmed',
    color: '#4caf78',
    bgColor: 'rgba(76, 175, 120, 0.12)',
  },
  rejected: {
    label: 'Rejected',
    color: '#e05555',
    bgColor: 'rgba(224, 85, 85, 0.12)',
  },
  completed: {
    label: 'Completed',
    color: '#4caf78',
    bgColor: 'rgba(76, 175, 120, 0.12)',
  },
  cancelled: {
    label: 'Cancelled',
    color: '#e05555',
    bgColor: 'rgba(224, 85, 85, 0.12)',
  },
  refunded: {
    label: 'Refunded',
    color: '#888',
    bgColor: 'rgba(136, 136, 136, 0.12)',
  },
};

export function getBookingStatusConfig(status: BookingStatus) {
  return bookingStatusConfig[status];
}
