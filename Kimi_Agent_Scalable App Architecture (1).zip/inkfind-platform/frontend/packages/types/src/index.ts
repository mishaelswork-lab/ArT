// ============================================
// INKFIND Platform - Shared TypeScript Types
// ============================================

// ============================================
// User Types
// ============================================
export type UserRole = 'super_admin' | 'sub_admin' | 'artist' | 'customer';

export interface User {
  id: string;
  shortId: string;
  phone: string;
  email?: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
  isActive: boolean;
  isVerified: boolean;
  createdAt: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface LoginResponse {
  user: User;
  tokens: AuthTokens;
}

// ============================================
// City Types
// ============================================
export interface City {
  id: string;
  shortId: string;
  name: string;
  state: string;
  country: string;
  latitude?: number;
  longitude?: number;
  studioCount?: number;
  artistCount?: number;
}

// ============================================
// Studio Types
// ============================================
export interface Studio {
  id: string;
  shortId: string;
  name: string;
  area: string;
  city: string;
  address: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  email?: string;
  website?: string;
  description?: string;
  coverImage?: string;
  images?: string[];
  styles: string[];
  openingHours?: Record<string, string>;
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  isOpen?: boolean;
  distance?: number;
  artists?: ArtistSummary[];
}

export interface StudioSummary {
  id: string;
  name: string;
  area: string;
  rating: number;
  reviewCount: number;
  coverImage?: string;
  styles: string[];
  distance?: number;
}

// ============================================
// Artist Types
// ============================================
export interface Artist {
  id: string;
  shortId: string;
  name: string;
  specialty: string;
  bio?: string;
  studio: StudioSummary;
  avatar?: string;
  hourlyRate: number;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  styles: string[];
  isAvailable: boolean;
  distance?: number;
  portfolio?: PortfolioImage[];
  availableSlots?: TimeSlot[];
  reviews?: Review[];
}

export interface ArtistSummary {
  id: string;
  name: string;
  specialty: string;
  avatar?: string;
  hourlyRate: number;
  rating: number;
}

export interface PortfolioImage {
  id: string;
  url: string;
  thumbnail?: string;
  caption?: string;
  style?: string;
}

// ============================================
// Booking Types
// ============================================
export type BookingStatus = 
  | 'pending_payment'
  | 'pending_artist'
  | 'confirmed'
  | 'rejected'
  | 'completed'
  | 'cancelled'
  | 'refunded';

export interface Booking {
  id: string;
  shortId: string;
  artist: ArtistSummary;
  studio: StudioSummary;
  customer?: User;
  slot: TimeSlot;
  coverCharge: {
    amount: number;
    currency: string;
    paid: boolean;
    paidAt?: string;
  };
  status: BookingStatus;
  tattooDescription: string;
  placement?: string;
  estimatedSize?: string;
  referenceImages?: string[];
  rejectionReason?: string;
  cancellationReason?: string;
  timeline?: BookingTimelineEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface BookingSummary {
  id: string;
  artist: ArtistSummary;
  studio: StudioSummary;
  slot: {
    date: string;
    time: string;
  };
  coverCharge: {
    amount: number;
    currency: string;
  };
  status: BookingStatus;
  tattooDescription: string;
  createdAt: string;
}

export interface BookingTimelineEvent {
  status: BookingStatus;
  timestamp: string;
  message: string;
}

export interface TimeSlot {
  id?: string;
  date: string;
  time: string;
  duration?: number;
  isAvailable?: boolean;
}

export interface CreateBookingRequest {
  artistId: string;
  slotDate: string;
  slotTime: string;
  duration: number;
  tattooDescription: string;
  placement?: string;
  estimatedSize?: string;
  referenceImages?: string[];
}

// ============================================
// Payment Types
// ============================================
export interface PaymentOrder {
  orderId: string;
  amount: number;
  currency: string;
  key: string;
  bookingId: string;
}

export interface PaymentVerification {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}

// ============================================
// Review Types
// ============================================
export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment?: string;
  date: string;
  isVerified?: boolean;
}

export interface CreateReviewRequest {
  bookingId: string;
  rating: number;
  comment?: string;
}

// ============================================
// Notification Types
// ============================================
export type NotificationType = 
  | 'booking_created'
  | 'booking_confirmed'
  | 'booking_rejected'
  | 'booking_cancelled'
  | 'payment_received'
  | 'payment_failed'
  | 'review_received'
  | 'general';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

// ============================================
// AI Consultant Types
// ============================================
export interface AIConsultationRequest {
  query: string;
}

export interface AIConsultationResponse {
  recommendation: string;
  suggestedStyles: string[];
  suggestedArtists?: ArtistSummary[];
  estimatedPriceRange?: {
    min: number;
    max: number;
    currency: string;
  };
}

// ============================================
// Admin Types
// ============================================
export interface AdminDashboardStats {
  totalArtists: number;
  totalStudios: number;
  totalBookings: number;
  pendingBookings: number;
  confirmedBookings: number;
  totalRevenue: number;
}

export interface CreateArtistRequest {
  name: string;
  email?: string;
  phone: string;
  studioId: string;
  specialty: string;
  bio?: string;
  hourlyRate: number;
  experienceYears?: number;
  styles: string[];
  password: string;
}

export interface CreateSubAdminRequest {
  name: string;
  phone: string;
  email?: string;
  canAddArtists?: boolean;
  canManageBookings?: boolean;
  canManagePayments?: boolean;
  canManageCities?: boolean;
  assignedCities?: string[];
}

// ============================================
// API Response Types
// ============================================
export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
}

export interface ApiError {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Array<{
      field: string;
      message: string;
    }>;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// ============================================
// Location Types
// ============================================
export interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

export interface NearbySearchParams {
  lat: number;
  lng: number;
  radius?: number;
  style?: string;
  rating?: number;
}

// ============================================
// Filter Types
// ============================================
export interface StudioFilter {
  city?: string;
  style?: string;
  rating?: number;
  lat?: number;
  lng?: number;
  radius?: number;
}

export interface ArtistFilter {
  studioId?: string;
  city?: string;
  style?: string;
  available?: boolean;
  lat?: number;
  lng?: number;
  radius?: number;
}

export interface BookingFilter {
  status?: BookingStatus;
}
