'use client';

import { Hero } from '@/components/sections/Hero';
import { AIConsultant } from '@/components/sections/AIConsultant';
import { StudioList } from '@/components/sections/StudioList';
import { LocationBanner } from '@/components/sections/LocationBanner';
import { useLocation } from '@/contexts/LocationContext';

export default function HomePage() {
  const { location, isLoading } = useLocation();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero />

      {/* Location Banner */}
      <div className="px-4 sm:px-6 lg:px-8">
        <LocationBanner />
      </div>

      {/* AI Consultant */}
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <AIConsultant />
      </div>

      {/* Studio List */}
      <div className="px-4 sm:px-6 lg:px-8 pb-20">
        <StudioList />
      </div>
    </div>
  );
}
