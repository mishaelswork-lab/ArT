import type { Metadata, Viewport } from 'next';
import { DM_Sans, Cinzel, Space_Mono } from 'next/font/google';
import './globals.css';
import { Providers } from './providers';
import { Navbar } from '@/components/layout/Navbar';
import { Toaster } from '@/components/ui/toaster';

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  weight: ['300', '400', '500', '600', '700'],
});

const cinzel = Cinzel({
  subsets: ['latin'],
  variable: '--font-cinzel',
  weight: ['400', '600', '700', '900'],
});

const spaceMono = Space_Mono({
  subsets: ['latin'],
  variable: '--font-space-mono',
  weight: ['400', '700'],
});

export const metadata: Metadata = {
  title: 'INKFIND - Find Your Perfect Tattoo Artist',
  description: 'Discover studios near you, browse portfolios, and book consultations with top tattoo artists across India.',
  keywords: ['tattoo', 'tattoo artist', 'tattoo studio', 'India', 'booking', 'inkfind'],
  authors: [{ name: 'INKFIND' }],
  openGraph: {
    title: 'INKFIND - Find Your Perfect Tattoo Artist',
    description: 'Discover studios near you, browse portfolios, and book consultations.',
    type: 'website',
    locale: 'en_IN',
    siteName: 'INKFIND',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'INKFIND - Find Your Perfect Tattoo Artist',
    description: 'Discover studios near you, browse portfolios, and book consultations.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: '#09090c',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${dmSans.variable} ${cinzel.variable} ${spaceMono.variable} font-sans antialiased`}
      >
        <Providers>
          <div className="min-h-screen bg-ink-bg text-white">
            <Navbar />
            <main className="pt-14">{children}</main>
            <Toaster />
          </div>
        </Providers>
      </body>
    </html>
  );
}
