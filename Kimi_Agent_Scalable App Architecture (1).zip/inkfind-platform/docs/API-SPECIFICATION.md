# INKFIND Platform - API Specification

## Base URL
```
Production:  https://api.inkfind.in/v1
Staging:     https://api-staging.inkfind.in/v1
Development: http://localhost:3001/v1
```

## Authentication
All protected endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <jwt_token>
```

---

## 📱 Authentication Endpoints

### POST /auth/register
Register a new user with phone number.

**Request:**
```json
{
  "phone": "+919876543210",
  "role": "customer",
  "name": "Rahul Sharma"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "OTP sent successfully",
  "data": {
    "otpId": "otp_123456",
    "expiresIn": 300
  }
}
```

---

### POST /auth/verify-otp
Verify OTP and complete registration/login.

**Request:**
```json
{
  "otpId": "otp_123456",
  "otp": "123456",
  "phone": "+919876543210"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "usr_abc123",
      "name": "Rahul Sharma",
      "phone": "+919876543210",
      "role": "customer",
      "avatarUrl": null
    },
    "tokens": {
      "accessToken": "eyJhbGciOiJIUzI1NiIs...",
      "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
      "expiresIn": 3600
    }
  }
}
```

---

### POST /auth/refresh
Refresh access token using refresh token.

**Request:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIs..."
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600
  }
}
```

---

### POST /auth/logout
Logout user and invalidate tokens.

**Response (200):**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

---

## 👤 User Endpoints

### GET /users/me
Get current user profile.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": "usr_abc123",
    "name": "Rahul Sharma",
    "phone": "+919876543210",
    "email": "rahul@example.com",
    "role": "customer",
    "avatarUrl": "https://cdn.inkfind.in/avatars/usr_abc123.jpg",
    "createdAt": "2026-03-29T10:00:00Z"
  }
}
```

---

### PUT /users/me
Update user profile.

**Request:**
```json
{
  "name": "Rahul Kumar Sharma",
  "email": "rahul.kumar@example.com"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Profile updated",
  "data": {
    "id": "usr_abc123",
    "name": "Rahul Kumar Sharma",
    "email": "rahul.kumar@example.com"
  }
}
```

---

### POST /users/avatar
Upload profile avatar.

**Request:** Multipart form-data
- `avatar`: File (jpg, png, max 5MB)

**Response (200):**
```json
{
  "success": true,
  "data": {
    "avatarUrl": "https://cdn.inkfind.in/avatars/usr_abc123.jpg"
  }
}
```

---

## 🏢 Studio Endpoints

### GET /studios
Get all studios with filters.

**Query Parameters:**
- `city` (string): Filter by city name
- `lat` (number): Latitude for nearby search
- `lng` (number): Longitude for nearby search
- `radius` (number): Search radius in km (default: 10)
- `style` (string): Filter by tattoo style
- `rating` (number): Minimum rating
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 20)

**Response (200):**
```json
{
  "success": true,
  "data": {
    "studios": [
      {
        "id": "stu_def456",
        "name": "Black Lotus Studio",
        "area": "Indiranagar",
        "city": "Bengaluru",
        "address": "123, 12th Main Road, Indiranagar",
        "latitude": 12.9784,
        "longitude": 77.6408,
        "rating": 4.9,
        "reviewCount": 214,
        "styles": ["Blackwork", "Fine Line", "Geometric"],
        "coverImage": "https://cdn.inkfind.in/studios/stu_def456/cover.jpg",
        "distance": 2.3,
        "isVerified": true,
        "isOpen": true
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 45,
      "totalPages": 3
    }
  }
}
```

---

### GET /studios/:id
Get studio details by ID.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": "stu_def456",
    "name": "Black Lotus Studio",
    "area": "Indiranagar",
    "city": "Bengaluru",
    "address": "123, 12th Main Road, Indiranagar",
    "phone": "+919876543210",
    "email": "contact@blacklotus.in",
    "latitude": 12.9784,
    "longitude": 77.6408,
    "rating": 4.9,
    "reviewCount": 214,
    "styles": ["Blackwork", "Fine Line", "Geometric"],
    "coverImage": "https://cdn.inkfind.in/studios/stu_def456/cover.jpg",
    "images": [
      "https://cdn.inkfind.in/studios/stu_def456/1.jpg",
      "https://cdn.inkfind.in/studios/stu_def456/2.jpg"
    ],
    "description": "Premium tattoo studio specializing in blackwork...",
    "openingHours": {
      "monday": "11:00-20:00",
      "tuesday": "11:00-20:00",
      "wednesday": "11:00-20:00",
      "thursday": "11:00-20:00",
      "friday": "11:00-20:00",
      "saturday": "10:00-21:00",
      "sunday": "12:00-18:00"
    },
    "isVerified": true,
    "artists": [
      {
        "id": "art_ghi789",
        "name": "Arjun Mehta",
        "specialty": "Blackwork & Geometric",
        "avatar": "https://cdn.inkfind.in/artists/art_ghi789.jpg",
        "hourlyRate": 3500,
        "rating": 4.9
      }
    ]
  }
}
```

---

## 🎨 Artist Endpoints

### GET /artists
Get all artists with filters.

**Query Parameters:**
- `studioId` (string): Filter by studio
- `city` (string): Filter by city
- `lat` (number): Latitude for nearby search
- `lng` (number): Longitude for nearby search
- `radius` (number): Search radius in km
- `style` (string): Filter by style
- `available` (boolean): Only available artists
- `page` (number): Page number
- `limit` (number): Items per page

**Response (200):**
```json
{
  "success": true,
  "data": {
    "artists": [
      {
        "id": "art_ghi789",
        "name": "Arjun Mehta",
        "specialty": "Blackwork & Geometric",
        "studio": {
          "id": "stu_def456",
          "name": "Black Lotus Studio",
          "area": "Indiranagar"
        },
        "avatar": "https://cdn.inkfind.in/artists/art_ghi789.jpg",
        "hourlyRate": 3500,
        "experienceYears": 10,
        "rating": 4.9,
        "reviewCount": 156,
        "styles": ["Blackwork", "Geometric", "Mandala"],
        "isAvailable": true,
        "distance": 2.3
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 128,
      "totalPages": 7
    }
  }
}
```

---

### GET /artists/:id
Get artist details by ID.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": "art_ghi789",
    "name": "Arjun Mehta",
    "specialty": "Blackwork & Geometric",
    "bio": "10 years crafting bold blackwork. Influenced by sacred geometry...",
    "studio": {
      "id": "stu_def456",
      "name": "Black Lotus Studio",
      "area": "Indiranagar",
      "city": "Bengaluru",
      "address": "123, 12th Main Road"
    },
    "avatar": "https://cdn.inkfind.in/artists/art_ghi789.jpg",
    "hourlyRate": 3500,
    "experienceYears": 10,
    "rating": 4.9,
    "reviewCount": 156,
    "styles": ["Blackwork", "Geometric", "Mandala"],
    "isAvailable": true,
    "portfolio": [
      {
        "id": "img_jkl012",
        "url": "https://cdn.inkfind.in/portfolio/art_ghi789/1.jpg",
        "thumbnail": "https://cdn.inkfind.in/portfolio/art_ghi789/1_thumb.jpg",
        "caption": "Sacred geometry sleeve",
        "style": "Geometric"
      }
    ],
    "availableSlots": [
      {
        "date": "2026-04-01",
        "time": "14:00",
        "duration": 120
      }
    ],
    "reviews": [
      {
        "id": "rev_mno345",
        "customerName": "Priya N",
        "rating": 5,
        "comment": "Amazing work! Very professional...",
        "date": "2026-03-15"
      }
    ]
  }
}
```

---

## 📅 Booking Endpoints

### POST /bookings
Create a new booking.

**Request:**
```json
{
  "artistId": "art_ghi789",
  "slotDate": "2026-04-01",
  "slotTime": "14:00",
  "duration": 120,
  "tattooDescription": "Small lotus on wrist, fine line style",
  "placement": "Left wrist",
  "estimatedSize": "5cm x 5cm",
  "referenceImages": [
    "https://cdn.inkfind.in/references/usr_abc123/1.jpg"
  ]
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Booking created",
  "data": {
    "id": "bkp_pqr678",
    "artist": {
      "id": "art_ghi789",
      "name": "Arjun Mehta"
    },
    "studio": {
      "id": "stu_def456",
      "name": "Black Lotus Studio"
    },
    "slot": {
      "date": "2026-04-01",
      "time": "14:00",
      "duration": 120
    },
    "coverCharge": {
      "amount": 50000,
      "currency": "INR",
      "amountFormatted": "₹500"
    },
    "status": "pending_payment",
    "createdAt": "2026-03-29T10:30:00Z",
    "payment": {
      "orderId": "order_abc123",
      "amount": 50000,
      "currency": "INR",
      "key": "rzp_test_xxx"
    }
  }
}
```

---

### GET /bookings
Get user's bookings.

**Query Parameters:**
- `status` (string): Filter by status
- `page` (number): Page number
- `limit` (number): Items per page

**Response (200):**
```json
{
  "success": true,
  "data": {
    "bookings": [
      {
        "id": "bkp_pqr678",
        "artist": {
          "id": "art_ghi789",
          "name": "Arjun Mehta",
          "avatar": "https://cdn.inkfind.in/artists/art_ghi789.jpg"
        },
        "studio": {
          "id": "stu_def456",
          "name": "Black Lotus Studio",
          "area": "Indiranagar"
        },
        "slot": {
          "date": "2026-04-01",
          "time": "14:00"
        },
        "coverCharge": {
          "amount": 500,
          "currency": "INR"
        },
        "status": "confirmed",
        "tattooDescription": "Small lotus on wrist...",
        "createdAt": "2026-03-29T10:30:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 5
    }
  }
}
```

---

### GET /bookings/:id
Get booking details.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": "bkp_pqr678",
    "artist": {
      "id": "art_ghi789",
      "name": "Arjun Mehta",
      "phone": "+919876543210",
      "avatar": "https://cdn.inkfind.in/artists/art_ghi789.jpg"
    },
    "studio": {
      "id": "stu_def456",
      "name": "Black Lotus Studio",
      "address": "123, 12th Main Road, Indiranagar",
      "phone": "+919876543211"
    },
    "customer": {
      "id": "usr_abc123",
      "name": "Rahul Sharma",
      "phone": "+919876543212"
    },
    "slot": {
      "date": "2026-04-01",
      "time": "14:00",
      "duration": 120
    },
    "coverCharge": {
      "amount": 500,
      "currency": "INR",
      "paid": true,
      "paidAt": "2026-03-29T10:35:00Z"
    },
    "status": "confirmed",
    "tattooDescription": "Small lotus on wrist, fine line style",
    "placement": "Left wrist",
    "estimatedSize": "5cm x 5cm",
    "referenceImages": [
      "https://cdn.inkfind.in/references/usr_abc123/1.jpg"
    ],
    "timeline": [
      {
        "status": "pending_payment",
        "timestamp": "2026-03-29T10:30:00Z",
        "message": "Booking created"
      },
      {
        "status": "pending_artist",
        "timestamp": "2026-03-29T10:35:00Z",
        "message": "Cover charge paid"
      },
      {
        "status": "confirmed",
        "timestamp": "2026-03-29T11:00:00Z",
        "message": "Artist confirmed booking"
      }
    ],
    "createdAt": "2026-03-29T10:30:00Z",
    "updatedAt": "2026-03-29T11:00:00Z"
  }
}
```

---

### PUT /bookings/:id/cancel
Cancel a booking.

**Request:**
```json
{
  "reason": "Change of plans"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Booking cancelled",
  "data": {
    "id": "bkp_pqr678",
    "status": "cancelled",
    "refund": {
      "amount": 500,
      "status": "processing",
      "estimatedDays": 5
    }
  }
}
```

---

## 💳 Payment Endpoints

### POST /payments/create-order
Create Razorpay order for cover charge.

**Request:**
```json
{
  "bookingId": "bkp_pqr678"
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "orderId": "order_abc123",
    "amount": 50000,
    "currency": "INR",
    "key": "rzp_test_xxx",
    "bookingId": "bkp_pqr678"
  }
}
```

---

### POST /payments/verify
Verify payment and update booking.

**Request:**
```json
{
  "razorpay_order_id": "order_abc123",
  "razorpay_payment_id": "pay_def456",
  "razorpay_signature": "signature_xyz"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Payment verified",
  "data": {
    "bookingId": "bkp_pqr678",
    "status": "pending_artist",
    "payment": {
      "id": "pay_def456",
      "amount": 500,
      "status": "captured"
    }
  }
}
```

---

## 🤖 AI Consultant Endpoints

### POST /ai/consult
Get AI tattoo style recommendations.

**Request:**
```json
{
  "query": "I want a small meaningful tattoo for my wrist, something related to strength and growth"
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "recommendation": "Based on your interest in strength and growth, I'd suggest a fine-line botanical design like a sprouting seed or a delicate lotus. These symbolize personal growth and resilience. For your wrist, a small 3-4cm design would work beautifully. I'd recommend checking out Priya Nair at Black Lotus Studio — she specializes in fine-line botanical work with a delicate touch inspired by Indian flora.",
    "suggestedStyles": ["Fine Line", "Botanical", "Minimalist"],
    "suggestedArtists": [
      {
        "id": "art_jkl012",
        "name": "Priya Nair",
        "studio": "Black Lotus Studio",
        "specialty": "Fine Line & Botanical"
      }
    ],
    "estimatedPriceRange": {
      "min": 2500,
      "max": 4500,
      "currency": "INR"
    }
  }
}
```

---

## ⭐ Review Endpoints

### POST /reviews
Submit a review for completed booking.

**Request:**
```json
{
  "bookingId": "bkp_pqr678",
  "rating": 5,
  "comment": "Amazing experience! Arjun was very professional..."
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Review submitted",
  "data": {
    "id": "rev_stu901",
    "bookingId": "bkp_pqr678",
    "rating": 5,
    "comment": "Amazing experience! Arjun was very professional...",
    "createdAt": "2026-04-02T15:00:00Z"
  }
}
```

---

## 🔔 Notification Endpoints

### GET /notifications
Get user notifications.

**Query Parameters:**
- `unreadOnly` (boolean): Only unread notifications
- `page` (number): Page number
- `limit` (number): Items per page

**Response (200):**
```json
{
  "success": true,
  "data": {
    "notifications": [
      {
        "id": "not_vwx234",
        "type": "booking_confirmed",
        "title": "Booking Confirmed!",
        "message": "Arjun Mehta has confirmed your booking for April 1st",
        "data": {
          "bookingId": "bkp_pqr678"
        },
        "isRead": false,
        "createdAt": "2026-03-29T11:00:00Z"
      }
    ],
    "unreadCount": 3
  }
}
```

---

### PUT /notifications/:id/read
Mark notification as read.

**Response (200):**
```json
{
  "success": true,
  "message": "Notification marked as read"
}
```

---

## 🔧 Admin Endpoints

### GET /admin/dashboard
Get admin dashboard stats.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "stats": {
      "totalArtists": 128,
      "totalStudios": 45,
      "totalBookings": 1256,
      "pendingBookings": 23,
      "confirmedBookings": 89,
      "totalRevenue": 625000
    },
    "recentBookings": [...],
    "topArtists": [...]
  }
}
```

---

### POST /admin/artists
Add new artist (Admin only).

**Request:**
```json
{
  "name": "Kavitha Shetty",
  "email": "kavitha@example.com",
  "phone": "+919876543213",
  "studioId": "stu_def456",
  "specialty": "Minimalist & Script",
  "bio": "Clean lines, intentional space...",
  "hourlyRate": 2800,
  "experienceYears": 5,
  "styles": ["Minimalist", "Script", "Dotwork"],
  "password": "tempPassword123"
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Artist added successfully",
  "data": {
    "id": "art_yza567",
    "name": "Kavitha Shetty",
    "loginCredentials": {
      "username": "kavitha",
      "tempPassword": "tempPassword123"
    }
  }
}
```

---

### GET /admin/artists
Get all artists for admin.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "artists": [
      {
        "id": "art_ghi789",
        "name": "Arjun Mehta",
        "studio": "Black Lotus Studio",
        "specialty": "Blackwork & Geometric",
        "hourlyRate": 3500,
        "status": "active",
        "totalBookings": 156,
        "rating": 4.9
      }
    ]
  }
}
```

---

### PUT /admin/artists/:id
Update artist details.

**Request:**
```json
{
  "hourlyRate": 4000,
  "status": "inactive"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Artist updated"
}
```

---

### POST /admin/sub-admins
Create sub-admin (Super admin only).

**Request:**
```json
{
  "name": "Rohit Manager",
  "phone": "+919876543214",
  "email": "rohit@inkfind.in",
  "canAddArtists": true,
  "canManageBookings": true,
  "assignedCities": ["Bengaluru", "Mumbai"]
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Sub-admin created",
  "data": {
    "id": "usr_mno345",
    "name": "Rohit Manager",
    "role": "sub_admin"
  }
}
```

---

## 🎨 Artist Dashboard Endpoints

### GET /artist/bookings
Get artist's bookings.

**Query Parameters:**
- `status` (string): pending, confirmed, rejected, all

**Response (200):**
```json
{
  "success": true,
  "data": {
    "bookings": [
      {
        "id": "bkp_pqr678",
        "customer": {
          "name": "Rahul Sharma",
          "phone": "+919876543212"
        },
        "slot": {
          "date": "2026-04-01",
          "time": "14:00"
        },
        "tattooDescription": "Small lotus on wrist...",
        "status": "pending",
        "coverCharge": 500,
        "createdAt": "2026-03-29T10:30:00Z"
      }
    ]
  }
}
```

---

### PUT /artist/bookings/:id/confirm
Confirm a booking.

**Response (200):**
```json
{
  "success": true,
  "message": "Booking confirmed",
  "data": {
    "id": "bkp_pqr678",
    "status": "confirmed"
  }
}
```

---

### PUT /artist/bookings/:id/reject
Reject a booking.

**Request:**
```json
{
  "reason": "Not available on this date"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Booking rejected",
  "data": {
    "id": "bkp_pqr678",
    "status": "rejected",
    "refundInitiated": true
  }
}
```

---

### PUT /artist/availability
Toggle availability status.

**Request:**
```json
{
  "isAvailable": false
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Availability updated",
  "data": {
    "isAvailable": false
  }
}
```

---

### POST /artist/portfolio
Upload portfolio image.

**Request:** Multipart form-data
- `image`: File (jpg, png, max 10MB)
- `caption`: string
- `style`: string

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": "img_jkl012",
    "url": "https://cdn.inkfind.in/portfolio/art_ghi789/2.jpg",
    "thumbnail": "https://cdn.inkfind.in/portfolio/art_ghi789/2_thumb.jpg",
    "caption": "Sacred geometry sleeve",
    "style": "Geometric"
  }
}
```

---

### DELETE /artist/portfolio/:id
Delete portfolio image.

**Response (200):**
```json
{
  "success": true,
  "message": "Image deleted"
}
```

---

## 🌐 City Endpoints

### GET /cities
Get all active cities.

**Response (200):**
```json
{
  "success": true,
  "data": {
    "cities": [
      {
        "id": "city_blr",
        "name": "Bengaluru",
        "state": "Karnataka",
        "studioCount": 45,
        "artistCount": 128
      },
      {
        "id": "city_mum",
        "name": "Mumbai",
        "state": "Maharashtra",
        "studioCount": 67,
        "artistCount": 198
      }
    ]
  }
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "phone",
        "message": "Invalid phone number format"
      }
    ]
  }
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Authentication required"
  }
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "Insufficient permissions"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Resource not found"
  }
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "Something went wrong"
  }
}
```

---

## Rate Limiting

- **Public endpoints**: 100 requests per minute
- **Authenticated endpoints**: 1000 requests per minute
- **File uploads**: 10 uploads per minute

Rate limit headers:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1711702800
```

---

## WebSocket Events

Connect to: `wss://api.inkfind.in/ws`

Authenticate with query param: `?token=<jwt_token>`

### Events

**Client → Server:**
```json
{
  "type": "subscribe",
  "channel": "bookings"
}
```

**Server → Client:**
```json
{
  "type": "notification",
  "data": {
    "event": "booking_confirmed",
    "bookingId": "bkp_pqr678",
    "message": "Your booking has been confirmed!"
  }
}
```

---

## Changelog

### v1.0.0 (2026-03-29)
- Initial API release
- Authentication with phone OTP
- Studio/Artist discovery
- Booking system with cover charge
- Payment integration with Razorpay
- Admin and Artist dashboards
- AI consultant integration
